"""Ingestion subsystem package."""
